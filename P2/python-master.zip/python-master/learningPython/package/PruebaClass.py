import Vehicle
objecta = Vehicle()
objectb = Vehicle()

objecta.str = "a"

print objecta.str + " " + objectb.str
