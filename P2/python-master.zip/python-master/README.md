Learning Python FTW!
Last tutorial: http://www.learnpython.org/en/Classes_and_Objects